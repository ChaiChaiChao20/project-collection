# ESP32 priority-vehicle traffic-light prototype

Two ESP32 sketches implement a tabletop model: an HC-SR04 detects a nearby object and a 433 MHz ASK/OOK transmitter sends a 32-bit priority frame; a receiver temporarily selects green while valid frames arrive. The supplied wiring guide maps the pins and explains the HC-SR04 echo voltage divider.

Upload `PriorityVehicleTransmitter.ino` to the vehicle ESP32 and `TrafficLightReceiver.ino` to the traffic-light ESP32. The transmitter and receiver must use the same `PRIORITY_CODE` and the matching pulse timing constants.

This is an educational tabletop prototype. The custom RF frame has no cryptographic authentication or robust interference correction and this controller must not operate real roads or replace certified traffic equipment. Use an appropriate regulated supply for the RF module and keep ESP32 GPIO inputs at 3.3 V or below.
