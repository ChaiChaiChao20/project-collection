# ESP32 emergency-priority traffic light

## What it does

Two ESP32 boards communicate through a 433 MHz ASK/OOK transmitter/receiver pair. The traffic-light board normally cycles **red 5 s → green 5 s → yellow 3 s**. The priority-vehicle board measures distance with an HC-SR04 and sends a coded RF frame when an object is detected within 150 cm. The receiver immediately displays green and keeps it green while valid frames continue, plus 1.2 s after the last frame. The normal cycle then resumes at its current phase.

This setup assumes two ESP32 DevKit-style boards, a 433 MHz RF TX/RX pair, an HC-SR04, three LEDs, and three 220–330 Ω LED resistors. The transmitter and receiver sketches are separate; upload each sketch to the corresponding ESP32.

## Wiring

### Traffic-light ESP32 (receiver)

| Part | Connection |
|---|---|
| Red LED anode | GPIO 25 through 220–330 Ω resistor |
| Yellow LED anode | GPIO 26 through 220–330 Ω resistor |
| Green LED anode | GPIO 27 through 220–330 Ω resistor |
| Each LED cathode | GND |
| 433 MHz receiver DATA | GPIO 34 |
| Receiver VCC/GND | Supply and ground required by that module; common GND with ESP32 |

### Priority-vehicle ESP32 (transmitter)

| Part | Connection |
|---|---|
| HC-SR04 TRIG | GPIO 19 |
| HC-SR04 ECHO | GPIO 18 through a 5 V-to-3.3 V divider |
| HC-SR04 VCC/GND | 5 V and GND, with GND shared with ESP32 |
| 433 MHz transmitter DATA | GPIO 23 |
| Transmitter VCC/GND | Supply required by that module; common GND with ESP32 |

For the HC-SR04 ECHO divider, use **1 kΩ from ECHO to GPIO 18** and **2 kΩ from GPIO 18 to GND**. ESP32 GPIOs are not 5 V tolerant. Check the RF module's rated supply and DATA output before wiring; keep every ESP32 input at or below 3.3 V. Do not connect 5 V directly to an ESP32 GPIO.

## Upload

In Arduino IDE, select an ESP32 Dev Module-compatible board and the COM port for the board currently connected by USB. Upload `TrafficLightReceiver.ino` to the traffic-light board, then connect the other board and upload `PriorityVehicleTransmitter.ino`. If the board does not appear as a COM port, install the correct USB-to-UART driver for its chip (commonly CP210x or CH340) and reconnect with a data-capable USB cable.

The current PC did not expose a serial/COM device during setup, so no board could be identified or flashed yet. Connect the traffic-light ESP32 over USB and continue; the board's USB-to-UART chip or COM port name will identify the serial interface, not necessarily the exact ESP32 module revision.
