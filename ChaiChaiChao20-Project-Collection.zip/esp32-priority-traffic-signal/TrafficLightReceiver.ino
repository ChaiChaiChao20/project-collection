#include <Arduino.h>

// Traffic-light controller: ESP32 + 433 MHz ASK/OOK receiver + 3 LEDs.
// Normal sequence: red 5 s, green 5 s, yellow 3 s. A valid priority RF
// frame overrides the displayed signal to green while frames keep arriving.

constexpr uint8_t RF_RX_PIN = 34;  // Input-only GPIO is suitable for receiver DATA.
constexpr uint8_t RED_LED_PIN = 25;
constexpr uint8_t YELLOW_LED_PIN = 26;
constexpr uint8_t GREEN_LED_PIN = 27;

constexpr uint32_t PRIORITY_CODE = 0xA5C31F79UL;
constexpr uint32_t PRIORITY_HOLD_MS = 1200;
constexpr uint32_t RED_MS = 5000;
constexpr uint32_t GREEN_MS = 5000;
constexpr uint32_t YELLOW_MS = 3000;
constexpr uint32_t CYCLE_MS = RED_MS + GREEN_MS + YELLOW_MS;

// Pulse timings must match PriorityVehicleTransmitter. The 4 ms sync mark is
// deliberately longer than any data mark; bit 1 is longer than bit 0.
constexpr uint32_t RF_PULSE_TIMEOUT_US = 10000;
constexpr uint32_t SYNC_MIN_US = 2500;
constexpr uint32_t BIT_MIN_US = 200;
constexpr uint32_t BIT_MAX_US = 1600;
constexpr uint32_t ONE_MIN_US = 700;

enum Signal : uint8_t { RED, GREEN, YELLOW };
int8_t displayedSignal = -1;
uint32_t priorityUntil = 0;
bool prioritySeen = false;
uint32_t cycleStart = 0;

bool readPriorityFrame(uint32_t &value) {
  // Scan one received high pulse. pulseIn waits for a pulse start, so this
  // also works when the receiver is idle-low or a frame starts between loops.
  const unsigned long mark = pulseIn(RF_RX_PIN, HIGH, RF_PULSE_TIMEOUT_US);
  if (mark < SYNC_MIN_US) return false;

  uint32_t candidate = 0;
  for (uint8_t bit = 0; bit < 32; ++bit) {
    const unsigned long bitMark = pulseIn(RF_RX_PIN, HIGH, RF_PULSE_TIMEOUT_US);
    if (bitMark < BIT_MIN_US || bitMark > BIT_MAX_US) return false;
    candidate = (candidate << 1) | (bitMark >= ONE_MIN_US ? 1UL : 0UL);
  }
  value = candidate;
  return true;
}

void showSignal(Signal signal) {
  if (displayedSignal == signal) return;
  digitalWrite(RED_LED_PIN, signal == RED ? HIGH : LOW);
  digitalWrite(YELLOW_LED_PIN, signal == YELLOW ? HIGH : LOW);
  digitalWrite(GREEN_LED_PIN, signal == GREEN ? HIGH : LOW);
  displayedSignal = signal;
}

Signal normalSignalAt(uint32_t now) {
  const uint32_t phase = (now - cycleStart) % CYCLE_MS;
  if (phase < RED_MS) return RED;
  if (phase < RED_MS + GREEN_MS) return GREEN;
  return YELLOW;
}

void setup() {
  pinMode(RF_RX_PIN, INPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(YELLOW_LED_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  cycleStart = millis();
  showSignal(RED);
}

void loop() {
  uint32_t receivedCode = 0;
  const uint32_t now = millis();
  if (readPriorityFrame(receivedCode) && receivedCode == PRIORITY_CODE) {
    priorityUntil = millis() + PRIORITY_HOLD_MS;
    prioritySeen = true;
  }

  const uint32_t updatedNow = millis();
  if (prioritySeen && static_cast<int32_t>(priorityUntil - updatedNow) > 0) {
    showSignal(GREEN);
  } else {
    prioritySeen = false;
    showSignal(normalSignalAt(updatedNow));
  }
}


