#include <Arduino.h>

// Priority-vehicle unit: ESP32 + HC-SR04 + 433 MHz ASK/OOK transmitter.
// Sends a repeated priority frame while an object is within 150 cm. The
// 180 cm release distance prevents rapid on/off switching near the threshold.

constexpr uint8_t TRIG_PIN = 19;
constexpr uint8_t ECHO_PIN = 18;  // Must receive <= 3.3 V; see wiring notes.
constexpr uint8_t RF_TX_PIN = 23;

constexpr uint32_t PRIORITY_CODE = 0xA5C31F79UL;
constexpr float TRIGGER_DISTANCE_CM = 150.0f;
constexpr float RELEASE_DISTANCE_CM = 180.0f;
constexpr uint32_t RANGE_INTERVAL_MS = 100;
constexpr uint32_t TRANSMIT_INTERVAL_MS = 200;

uint8_t nearSamples = 0;
bool vehicleNear = false;
uint32_t lastRangeAt = 0;
uint32_t lastTransmitAt = 0;

void transmitPriorityFrame() {
  // Sync mark and gap, followed by 32 MSB-first pulse-width-coded bits.
  digitalWrite(RF_TX_PIN, HIGH);
  delayMicroseconds(4000);
  digitalWrite(RF_TX_PIN, LOW);
  delayMicroseconds(1200);

  for (int8_t bit = 31; bit >= 0; --bit) {
    const bool one = (PRIORITY_CODE >> bit) & 1UL;
    digitalWrite(RF_TX_PIN, HIGH);
    delayMicroseconds(one ? 1000 : 400);
    digitalWrite(RF_TX_PIN, LOW);
    delayMicroseconds(400);
  }
}

float measureDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(3);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  const unsigned long duration = pulseIn(ECHO_PIN, HIGH, 25000UL);
  if (duration == 0) return -1.0f;  // No echo is treated as out of range.
  return duration * 0.0343f / 2.0f;
}

void updateRange() {
  const float distanceCm = measureDistanceCm();
  if (distanceCm >= 0 && distanceCm <= TRIGGER_DISTANCE_CM) {
    if (nearSamples < 3) ++nearSamples;
    if (nearSamples >= 2) vehicleNear = true;
  } else if (distanceCm < 0 || distanceCm >= RELEASE_DISTANCE_CM) {
    nearSamples = 0;
    vehicleNear = false;
  }
  // Between 150 cm and 180 cm, retain the previous state (hysteresis).
}

void setup() {
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(RF_TX_PIN, OUTPUT);
  digitalWrite(RF_TX_PIN, LOW);
}

void loop() {
  const uint32_t now = millis();
  if (now - lastRangeAt >= RANGE_INTERVAL_MS) {
    lastRangeAt = now;
    updateRange();
  }

  if (vehicleNear && now - lastTransmitAt >= TRANSMIT_INTERVAL_MS) {
    lastTransmitAt = now;
    transmitPriorityFrame();
  }
}
